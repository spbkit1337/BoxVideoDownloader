﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




//мои юзынги
using System.Diagnostics; //cmd для выполнения произвольной команды

using System.IO; // show dialog показать диалоговое окно сохранения
using System.Net;

namespace BoxVideoDownloader
{
    public partial class Form1 : Form
    {
        //переменные которые содержат пустой путь 
        
        string output = System.IO.Path.Combine(Application.StartupPath, "");
        string output2 = System.IO.Path.Combine(Application.StartupPath, "");
        string path = System.IO.Path.Combine(Application.StartupPath, "");


        string pathDesktop = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Desktop");


        //переменные для скачивания списком через list view
        string link = ""; 
        ListView list = new ListView();

        //скачивание по прямой ссылке файлов

        string linkfile = "";


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
       
        }
        

        //путь сохранения картинка m3u8
        void pictureBox1_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Видео (*. mp4) | * .mp4 | Рабочий лист (*. mp4) | * .mp4";

            if (sfd.ShowDialog() == DialogResult.OK)
            {

                output = sfd.FileName;
                label4.Text = output.ToString();

                //output = saveFileDialog1.FileName;
                //label4.Text = output.ToString();
            }

        }

        //кнопка скачивания m3u8
        private void button1_Click(object sender, EventArgs e)
        {

            string linkM3u8 = textBox1.Text.ToString();

            string PathM3u8 = output;

            ProcessStartInfo psi = new ProcessStartInfo();
            //Имя запускаемого приложения
            psi.FileName = "cmd";
            //команда, которую надо выполнить

            psi.Arguments = $" @\"/c ffmpeg -i {linkM3u8} -c copy -bsf:a aac_adtstoasc {PathM3u8} ";



            //  /c - после выполнения команды консоль закроется
            //  /к - не закрывать консоль после выполнения команды
            Process.Start(psi);

        }



        //путь сохранения видео  youtube
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    path = dialog.SelectedPath;
                    label5.Text = path.ToString();
                }

            }
        }

        //путь сохранения плэйлиста  youtube
        void pictureBox10_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    path = dialog.SelectedPath;
                    label13.Text = path.ToString();
                }

            }

        }





        //кнопка скачивания youtube

        //обычный ролик
        private void button2_Click(object sender, EventArgs e)
        {
            ProcessStartInfo psi = new ProcessStartInfo();

            string linkYoutube = textBox2.Text.ToString();



            //если true то скачать только аудио
            if (checkBox1.Checked == true)
            {
                //Имя запускаемого приложения
                psi.FileName = "cmd";
                //команда, которую надо выполнить


                psi.Arguments = $" @\"/c yt-dlp  --extract-audio --audio-format mp3 {linkYoutube} -o %(title)s.%(ext)s   -P {path}";


                

                //  /c - после выполнения команды консоль закроется
                //  /к - не закрывать консоль после выполнения команды
                Process.Start(psi);
            }
            else //false скачать как видео
            {
                //Имя запускаемого приложения
                psi.FileName = "cmd";
                //команда, которую надо выполнить

                //строка --merge-output-format mp4 озночает что видео даже если webm то оно конвертнется в mp4
                psi.Arguments = $" @\"/c yt-dlp  {linkYoutube}  --merge-output-format mp4 -P {path}";


                //  /c - после выполнения команды консоль закроется
                //  /к - не закрывать консоль после выполнения команды
                Process.Start(psi);
            }
        }


        // плэйлист

        private void button4_Click(object sender, EventArgs e)
        {
            //если галка нажата то скачает в формате mp3
            if (checkBox2.Checked == true)
            {
                ProcessStartInfo playlist = new ProcessStartInfo();

                string linkYoutubePlaylist = textBox3.Text.ToString();


                //Имя запускаемого приложения
                playlist.FileName = "cmd";
                //команда, которую надо выполнить
                //здесь выпоняются несоклько команд сначало переход в директорию , а затем скачивание плейлиста .Чтобы выпонить несоклько команд поочередно я юзаю &&
                playlist.Arguments = $" @\"/c yt-dlp  --extract-audio --audio-format mp3  {linkYoutubePlaylist}  -o %(title)s.%(ext)s -P {path}";


                //  /c - после выполнения команды консоль закроется
                //  /к - не закрывать консоль после выполнения команды
                Process.Start(playlist);
            }
            else //если не нажата то скачает в формате mp4
            {
                ProcessStartInfo playlist = new ProcessStartInfo();

                string linkYoutubePlaylist = textBox3.Text.ToString();


                //Имя запускаемого приложения
                playlist.FileName = "cmd";
                //команда, которую надо выполнить
                //здесь выпоняются несоклько команд сначало переход в директорию , а затем скачивание плейлиста .Чтобы выпонить несоклько команд поочередно я юзаю &&
                playlist.Arguments = $" @\"/c yt-dlp --no-playlist  {linkYoutubePlaylist} --merge-output-format mp4 -P {path}";


                //  /c - после выполнения команды консоль закроется
                //  /к - не закрывать консоль после выполнения команды
                Process.Start(playlist);
            }
        }


        //извлечь аудио
        //находим файл
        private void pictureBox11_Click(object sender, EventArgs e)
        {
            OpenFileDialog PathAudioOpen = new OpenFileDialog();
            PathAudioOpen.Filter = "Видео | * .mp4";
            if (PathAudioOpen.ShowDialog() == DialogResult.OK)
            {
                output = PathAudioOpen.FileName;
                textBox6.Text = output.ToString();
            }
        }
        //сохраняем файл
        private void pictureBox9_Click(object sender, EventArgs e)
        {
            SaveFileDialog PathAudioSave = new SaveFileDialog();
            PathAudioSave.Filter = "Аудио | * .mp3";
            if (PathAudioSave.ShowDialog() == DialogResult.OK)
            {
                output2 = PathAudioSave.FileName;
                textBox7.Text = output2.ToString();
            }
        }

        //кнопка извлечь аудио
        private void button3_Click(object sender, EventArgs e)
        {
            ProcessStartInfo psi = new ProcessStartInfo();

            string AudioOpen = output;
            string AudioSave = output2;
            //Имя запускаемого приложения
            psi.FileName = "cmd";
            //команда, которую надо выполнить

            psi.Arguments = $" @\"/c ffmpeg -i {AudioOpen} -vn -ar 44100 -ac 2 -ab 192K -f mp3 {AudioSave}";


            //  /c - после выполнения команды консоль закроется
            //  /к - не закрывать консоль после выполнения команды
            Process.Start(psi);
        }

        //конвертировать в GIF


        //открыть видео
        private void pictureBox18_Click(object sender, EventArgs e)
        {
            OpenFileDialog PathAudioOpen = new OpenFileDialog();
            PathAudioOpen.Filter = "Видео | * .mp4";
            if (PathAudioOpen.ShowDialog() == DialogResult.OK)
            {
                output = PathAudioOpen.FileName;
                textBox4.Text = output.ToString();
            }
        }


        //сохранить в формате gif
        private void pictureBox20_Click(object sender, EventArgs e)
        {
            SaveFileDialog PathAudioSave = new SaveFileDialog();
            PathAudioSave.Filter = "GIF | * .gif";
            if (PathAudioSave.ShowDialog() == DialogResult.OK)
            {
                output2 = PathAudioSave.FileName;
                textBox5.Text = output2.ToString();
            }
        }

        //кнопка конвертации видео в gif
        private void button5_Click(object sender, EventArgs e)
        {
            ProcessStartInfo psi = new ProcessStartInfo();

            string GIFOpen = output;
            string GIFSave = output2;
            //Имя запускаемого приложения
            psi.FileName = "cmd";
            //команда, которую надо выполнить

            psi.Arguments = $" @\"/c ffmpeg -i {GIFOpen} {GIFSave}";


            //  /c - после выполнения команды консоль закроется
            //  /к - не закрывать консоль после выполнения команды
            Process.Start(psi);
        }






        //добавление ссылок
        private void button6_Click(object sender, EventArgs e)
        {
            string link = textBox8.Text;

            textBox8.Text = ""; //после того как дабовлю ссылку на видео очищу полю для ссылки

            //listView1.Items.Add(link);

            //получаю данные из cmd , а именно название видео
            Process process = Process.Start(new ProcessStartInfo
            {
                FileName = "cmd",
                //CreateNoWindow = true, //не показывать окна ВООБЩЕ
                UseShellExecute = false,
                RedirectStandardOutput = true,
                Arguments = $" @\"/c yt-dlp {link} --get-title",
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,

                //c - после выполнения команды консоль закроется
                //к - не закрывать консоль после выполнения команды
            });

            //тут создается переменная в которой можно поместить какие либо данные
            //например можно написать вот так     var item1 = new ListViewItem(new[] { "", "","" });
            // "" это по сути значение в колонке.Ты можешь создать допусти 3 колонки и запонить тремя ""  или поставить свою переменную

            var item1 = new ListViewItem(new[] { link, process.StandardOutput.ReadToEnd() });

            //добавляем переменную item1 в список list view
            listView1.Items.Add(item1);


        }


        //путь сохранения всех видосов list view
        private void pictureBox24_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    path = dialog.SelectedPath;
                    label10.Text = path.ToString();
                }

            }
        }




        //скачивание роликов
        private void button7_Click(object sender, EventArgs e)
        {
            //тут идет  цикл при котором каждый элемент в list view , а именно item будет выполнена команда в cmd 
            foreach (ListViewItem s in listView1.Items)
            {
                //тут немного по другому написал выполнение команды но по сути тоже самое только без psi
                Process.Start(new ProcessStartInfo
                {
                    FileName = "cmd",
                    //CreateNoWindow = true, //не показывать окна ВООБЩЕ
                    Arguments = $" @\"/c yt-dlp  {s.Text} --merge-output-format mp4 -P {path}",
                    //после выполнения команды окно само закроется что будет говорить о выполнении

                    //    //  /c - после выполнения команды консоль закроется
                    //    //  /к - не закрывать консоль после выполнения команды

                });
            }
        }

        //очистить listview
        private void button8_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }

        //удалить определенный list view
        private void button9_Click(object sender, EventArgs e)
        {
            //тут удаляется не все элементы , а лишь выбранный 
            foreach (ListViewItem eachItem in listView1.SelectedItems)
            {
                listView1.Items.Remove(eachItem);
            }
        }




        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
        }

        private void выйтиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md");
        }

        //путь сохранения файла по прямой ссылке
        private void pictureBox30_Click(object sender, EventArgs e)
        {
            SaveFileDialog linkfile = new SaveFileDialog();
            linkfile.Filter = "Файл | * .exe";
            if (linkfile.ShowDialog() == DialogResult.OK)
            {
                output2 = linkfile.FileName;
                label20.Text = output2.ToString();
            }
        }

        //скачивание файлов по прямой ссылке
        //в ролике у христа  написано EventArgs e я написал "a" потому что какая то ошибка
        void button10_Click(object sender, EventArgs a)
        {
            linkfile = textBox9.Text.ToString(); //ссылка на файл

            using (WebClient wc = new WebClient())
            {
                
                wc.OpenRead(linkfile); //это нужно чтобы получить размер файла

                string size = (Convert.ToDouble(wc.ResponseHeaders["Content-length"]) / 1024 / 1024).ToString("#.# МБ"); //получаем размер файла  в МБ 

                wc.DownloadProgressChanged += (s, e) =>
                {
                    label22.Text =  $"Загружено: {e.ProgressPercentage}%({((double)e.BytesReceived / 1024 / 1024).ToString("#.# МБ")} )"; // получение размера уже скачаенного 

                    label23.Text = $"Размер файла : {size}";

                    progressBar1.Value = e.ProgressPercentage; //изменение значение прогрес бара по мере скачивания
                };

               

                wc.DownloadFileAsync(new Uri ($"{linkfile}") , $"{output2}"); //скачивание файла откуда и куда
            }
        }


    }

}
